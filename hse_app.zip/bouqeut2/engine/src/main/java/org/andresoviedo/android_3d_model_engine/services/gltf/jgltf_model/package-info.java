/**
 * Classes for loading and accessing glTF data. These are basic utility
 * classes that offer "convenience" access to the glTF data in a form
 * that is specific for Java, but not specific for the application. 
 */
package org.andresoviedo.android_3d_model_engine.services.gltf.jgltf_model;

