package org.andresoviedo.android_3d_model_engine.services.stl;

import android.app.Activity;

/**
 * Created by andres on 17/04/17.
 */

public class Component extends Activity {
}
