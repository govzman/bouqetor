/**
 * Implementation of the glTF structure. The classes in this package
 * are automatically generated from the schema. They may change when
 * the schema is updated, and should not be modified manually.
 */
package org.andresoviedo.android_3d_model_engine.services.gltf.jgltf_model.impl.v1;

