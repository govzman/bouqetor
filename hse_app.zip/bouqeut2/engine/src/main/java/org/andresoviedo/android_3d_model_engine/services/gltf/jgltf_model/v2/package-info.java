/**
 * Implementations for the {@link org.andresoviedo.android_3d_model_engine.services.gltf.jgltf_model.GltfModel} classes,
 * based on glTF 2.0.<br>
 * <br>
 * In most cases, these classes should not directly be used by clients.
 */
package org.andresoviedo.android_3d_model_engine.services.gltf.jgltf_model.v2;

