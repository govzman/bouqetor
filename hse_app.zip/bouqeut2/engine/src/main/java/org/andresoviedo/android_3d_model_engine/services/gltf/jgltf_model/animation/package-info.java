/**
 * Classes for handling animations. These are simple (but generic) utility
 * classes for arbitrary animations, largely independent of glTF, but
 * limited to the functionality that is required for glTF.
 */
package org.andresoviedo.android_3d_model_engine.services.gltf.jgltf_model.animation;

