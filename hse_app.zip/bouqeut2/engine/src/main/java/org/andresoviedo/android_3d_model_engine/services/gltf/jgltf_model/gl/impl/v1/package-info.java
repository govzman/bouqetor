/**
 * Implementations of the <code>de.javagl.jgltf.model.gl</code> classes,
 * for glTF 1.0.<br>
 * <br>  
 * These classes should not be considered to be part of the public API.
 */
package org.andresoviedo.android_3d_model_engine.services.gltf.jgltf_model.gl.impl.v1;

